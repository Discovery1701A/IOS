//
//  Controler.swift
//  Memory
//
//  Created by Anna Rieckmann on 26.09.23.
//

import Foundation

class Controler {
    var tierArray: Array <String> = ["🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐻‍❄️","🐨","🐯","🦁","🐮","🐷"]
    var emojis : Array <String> = []
    func neuesSpiel (){
        
        
    }
}
